
#include <WiFi.h>
// Update these with values suitable for your network.
const char *ssid = "3STechLabs";
const char *password = "%@3stech@nauman%";