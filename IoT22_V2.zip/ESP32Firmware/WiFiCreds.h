
#include <WiFi.h>
// Update these with values suitable for your network.
const char *ssid = "hotspot2";
const char *password = "abc123098a#";